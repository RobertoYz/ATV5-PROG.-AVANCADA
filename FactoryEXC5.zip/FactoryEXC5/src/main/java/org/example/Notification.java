package org.example;

public interface Notification {
    void send(String message);
}
